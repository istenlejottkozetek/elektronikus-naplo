﻿public class Jegy
{
    public int Ertek { get; set; }
    public string Tema { get; set; }
    public string SzamonkeresTipusa { get; set; }

    public Jegy(int ertek, string tema, string szamonkeresTipusa)
    {
        Ertek = ertek;
        Tema = tema;
        SzamonkeresTipusa = szamonkeresTipusa;
    }
}
