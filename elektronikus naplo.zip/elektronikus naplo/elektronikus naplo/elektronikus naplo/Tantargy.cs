﻿using System.Collections.Generic;
using System.Linq;

public class Tantargy
{
    public string Nev { get; set; }
    public List<Jegy> Jegyek { get; set; }

    public Tantargy(string nev)
    {
        Nev = nev;
        Jegyek = new List<Jegy>();
    }

    public double GetAtlag()
    {
        if (Jegyek.Count == 0)
            return 0;

        return Jegyek.Average(j => j.Ertek);
    }
}
