﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace ElektronikusEllenorzo
{
    public partial class MainWindow : Window
    {
        private List<Tanulo> tanulok;

        public MainWindow()
        {
            InitializeComponent();
            tanulok = new List<Tanulo>();
            FeltoltTesztAdatokkal();
            BeallitTanuloValasztot();
            BeallitTantargyValasztot();
        }


        private void FeltoltTesztAdatokkal()
        {
            var tanulo1 = new Tanulo("Tanuló 1");
            var tantargy1 = new Tantargy("Matematika");
            tantargy1.Jegyek.Add(new Jegy(5, "Algebra", "Írásbeli"));
            tanulo1.Tantargyak.Add(tantargy1);

            var tantargy2 = new Tantargy("Történelem");
            tantargy2.Jegyek.Add(new Jegy(4, "Magyar történelem", "Szóbeli"));
            tanulo1.Tantargyak.Add(tantargy2);

            var tanulo2 = new Tanulo("Tanuló 2");
            var tantargy3 = new Tantargy("Informatika");
            tantargy3.Jegyek.Add(new Jegy(3, "Programozás", "Gyakorlati"));
            tanulo2.Tantargyak.Add(tantargy3);

            tanulok.Add(tanulo1);
            tanulok.Add(tanulo2);
        }


        private void BeallitTanuloValasztot()
        {
            foreach (var tanulo in tanulok)
            {
                TanuloValaszto.Items.Add(tanulo.Nev);
            }
        }


        private void BeallitTantargyValasztot()
        {
            if (tanulok.Count > 0)
            {
                var tanulo = tanulok[0];
                TantargyValaszto.ItemsSource = tanulo.Tantargyak.Select(t => t.Nev).ToList();
            }
        }


        private void BejelentkezesGomb_Click(object sender, RoutedEventArgs e)
        {
            string kivalasztottTanuloNev = TanuloValaszto.SelectedItem?.ToString();
            var tanulo = tanulok.FirstOrDefault(t => t.Nev == kivalasztottTanuloNev);

            if (tanulo != null)
            {
                MessageBox.Show($"{tanulo.Nev} bejelentkezett.");
                TantargyValaszto.ItemsSource = tanulo.Tantargyak.Select(t => t.Nev).ToList(); // Frissíti a tantárgylistát a kiválasztott tanuló alapján
            }
            else
            {
                MessageBox.Show("Válassz ki egy tanulót!");
            }
        }


        private void JegyHozzaadasGomb_Click(object sender, RoutedEventArgs e)
        {
            string kivalasztottTanuloNev = TanuloValaszto.SelectedItem?.ToString();
            var tanulo = tanulok.FirstOrDefault(t => t.Nev == kivalasztottTanuloNev);

            if (tanulo != null)
            {
                string kivalasztottTantargyNev = TantargyValaszto.SelectedItem?.ToString();
                var tantargy = tanulo.Tantargyak.FirstOrDefault(t => t.Nev == kivalasztottTantargyNev);

                if (tantargy != null)
                {
                    int jegyErtek;
                    if (int.TryParse(JegySzoveg.Text, out jegyErtek))
                    {
                        string tema = TemaSzoveg.Text;
                        string szamonkeresTipusa = SzamonkeresTipusaSzoveg.Text;

                        tantargy.Jegyek.Add(new Jegy(jegyErtek, tema, szamonkeresTipusa));
                        MessageBox.Show($"Jegy hozzáadva: {tantargy.Nev}, Jegy: {jegyErtek}, Téma: {tema}, Számonkérés: {szamonkeresTipusa}");
                    }
                    else
                    {
                        MessageBox.Show("Hibás jegyérték! Írj be egy számot.");
                    }
                }
                else
                {
                    MessageBox.Show("Válassz ki egy tantárgyat!");
                }
            }
            else
            {
                MessageBox.Show("Válassz ki egy tanulót!");
            }
        }
]

        private void AdminGomb_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder statisztika = new StringBuilder();
            foreach (var tanulo in tanulok)
            {
                statisztika.AppendLine($"{tanulo.Nev} - Összesített átlag: {tanulo.GetOsszesitettAtlag():0.00}");
                foreach (var tantargy in tanulo.Tantargyak)
                {
                    statisztika.AppendLine($"\t{tantargy.Nev} - Tantárgyi átlag: {tantargy.GetAtlag():0.00}");
                }
            }
            MessageBox.Show(statisztika.ToString());
        }
    }

    public class Tanulo
    {
        public string Nev { get; set; }
        public List<Tantargy> Tantargyak { get; set; }

        public Tanulo(string nev)
        {
            Nev = nev;
            Tantargyak = new List<Tantargy>();
        }

        public double GetOsszesitettAtlag()
        {
            if (Tantargyak.Count == 0)
                return 0;

            double osszesJegy = Tantargyak.Sum(t => t.GetAtlag());
            return osszesJegy / Tantargyak.Count;
        }
    }

    public class Tantargy
    {
        public string Nev { get; set; }
        public List<Jegy> Jegyek { get; set; }

        public Tantargy(string nev)
        {
            Nev = nev;
            Jegyek = new List<Jegy>();
        }

        public double GetAtlag()
        {
            if (Jegyek.Count == 0)
                return 0;

            return Jegyek.Average(j => j.Ertek);
        }
    }

    public class Jegy
    {
        public int Ertek { get; set; }
        public string Tema { get; set; }
        public string SzamonkeresTipusa { get; set; }

        public Jegy(int ertek, string tema, string szamonkeresTipusa)
        {
            Ertek = ertek;
            Tema = tema;
            SzamonkeresTipusa = szamonkeresTipusa;
        }
    }
}
