﻿using System.Collections.Generic;
using System.Linq;

public class Tanulo
{
    public string Nev { get; set; }
    public List<Tantargy> Tantargyak { get; set; }
    public bool Lemorzsolodott { get; set; }

    public Tanulo(string nev)
    {
        Nev = nev;
        Tantargyak = new List<Tantargy>();
        Lemorzsolodott = false;
    }

    public double GetOsszesitettAtlag()
    {
        if (Tantargyak.Count == 0)
            return 0;

        double osszesJegy = Tantargyak.Sum(t => t.GetAtlag());
        return osszesJegy / Tantargyak.Count;
    }

    public void CheckLemorzsolodas()
    {
        int bukasraAlloTantargyak = Tantargyak.Count(t => t.GetAtlag() < 2);
        Lemorzsolodott = bukasraAlloTantargyak >= 3;
    }
}
